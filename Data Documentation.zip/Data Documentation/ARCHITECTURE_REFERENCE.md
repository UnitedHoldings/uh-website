# 🗺️ CMS Architecture & Data Flow Reference

## System Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                     CLIENT LAYER (React/Next.js)                │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐           │
│  │   Products   │  │   Reviews    │  │     Team     │           │
│  │  Components  │  │  Components  │  │  Components  │           │
│  └──────┬───────┘  └──────┬───────┘  └──────┬───────┘           │
│         │                 │                 │                    │
│         └─────────────────┼─────────────────┘                    │
│                           │                                      │
│                    ┌──────▼──────┐                               │
│                    │  useCSM()    │                              │
│                    │   Hooks      │                              │
│                    └──────┬───────┘                              │
│                           │                                      │
│                    ┌──────▼──────┐                               │
│                    │ CMS API      │                              │
│                    │ Service      │                              │
│                    └──────┬───────┘                              │
│                           │                                      │
│         ┌─────────────────┼─────────────────┐                   │
│         │                 │                 │                   │
│    ┌────▼───┐       ┌──────▼──────┐   ┌────▼──────┐            │
│    │ Fetch  │       │   Cache     │   │ Error     │            │
│    │        │       │  (localStorage) │ Handler   │            │
│    └────┬───┘       └──────┬──────┘   └────┬──────┘            │
│         │                  │               │                    │
│         └──────────────────┼───────────────┘                    │
│                            │                                    │
│                      ┌─────▼──────┐                             │
│                      │   HTTP     │                             │
│                      │  (HTTPS)   │                             │
│                      └─────┬──────┘                             │
│                            │                                    │
└────────────────────────────┼────────────────────────────────────┘
                             │
                             │ API Requests
                             │
┌────────────────────────────▼────────────────────────────────────┐
│                    API GATEWAY / SERVER LAYER                    │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌─────────────────────────────────────────┐                    │
│  │  Route: /api/cms/*                      │                    │
│  │  ├── Authentication (JWT)               │                    │
│  │  ├── Authorization (Role-based)         │                    │
│  │  ├── Validation                         │                    │
│  │  ├── Rate Limiting                      │                    │
│  │  └── Error Handling                     │                    │
│  └─────────────────────────────────────────┘                    │
│         │             │             │             │             │
│    ┌────▼────┐  ┌─────▼─────┐ ┌────▼────┐ ┌──────▼──────┐     │
│    │Products │  │  Reviews  │ │  Team   │ │  Branches   │     │
│    │ Routes  │  │ Routes    │ │ Routes  │ │  Routes     │     │
│    └────┬────┘  └─────┬─────┘ └────┬────┘ └──────┬──────┘     │
│         │             │            │            │              │
│         └─────────────┼────────────┼────────────┘              │
│                       │            │                           │
│                    ┌──▼─────────────▼──┐                       │
│                    │  Business Logic    │                       │
│                    │  & Transformations │                       │
│                    └──────────┬─────────┘                       │
│                               │                                │
│                        ┌──────▼──────┐                         │
│                        │   Database  │                         │
│                        │   Queries   │                         │
│                        └──────┬──────┘                         │
│                               │                                │
└───────────────────────────────┼────────────────────────────────┘
                                │
                                │ SQL Queries
                                │
┌───────────────────────────────▼────────────────────────────────┐
│              DATABASE LAYER (PostgreSQL)                        │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌──────────────────────────────────────────┐                  │
│  │  Tables:                                 │                  │
│  │  ├── companies                           │                  │
│  │  ├── products                            │                  │
│  │  ├── product_benefits                    │                  │
│  │  ├── product_coverage                    │                  │
│  │  ├── product_exclusions                  │                  │
│  │  ├── product_faqs                        │                  │
│  │  ├── reviews                             │                  │
│  │  ├── team_members                        │                  │
│  │  ├── branches                            │                  │
│  │  ├── hero_slides                         │                  │
│  │  ├── reasons                             │                  │
│  │  ├── form_configs                        │                  │
│  │  ├── form_fields                         │                  │
│  │  └── configurations                      │                  │
│  └──────────────────────────────────────────┘                  │
│                                                                   │
└─────────────────────────────────────────────────────────────────┘
```

---

## Data Flow Diagram: Getting Products

```
┌─────────────┐
│   Browser   │
│   Loads     │
│   Page      │
└──────┬──────┘
       │
       ▼
┌──────────────────────────┐
│ useProducts()            │
│ Hook Called              │
│ (components/Products)    │
└──────┬───────────────────┘
       │
       ▼
┌──────────────────────────┐
│ useEffect Runs           │
│ Calls CMS_API.products   │
└──────┬───────────────────┘
       │
       ▼
┌──────────────────────────────┐
│ fetch('/api/cms/products')   │
│ Sends GET Request            │
└──────┬──────────────────────┘
       │
       ▼
┌───────────────────────────────────────┐
│ Server: /api/cms/products             │
│ - Check Authentication (JWT)          │
│ - Check Authorization                 │
│ - Query Database                      │
│ - Get all published products          │
└──────┬────────────────────────────────┘
       │
       ▼
┌──────────────────────────────┐
│ Database Query               │
│ SELECT * FROM products       │
│ WHERE status = 'published'   │
│ JOIN benefits, coverage...   │
└──────┬──────────────────────┘
       │
       ▼
┌──────────────────────────────┐
│ Results: 25 Products         │
│ With all related data        │
└──────┬──────────────────────┘
       │
       ▼
┌──────────────────────────────┐
│ Transform Data               │
│ Serialize to JSON            │
│ Add metadata                 │
└──────┬──────────────────────┘
       │
       ▼
┌─────────────────────────────────────┐
│ HTTP Response (200 OK)              │
│ {                                   │
│   "success": true,                  │
│   "data": [                         │
│     { id, name, benefits... },      │
│     { id, name, benefits... },      │
│     ...                             │
│   ]                                 │
│ }                                   │
└──────┬────────────────────────────┘
       │
       ▼
┌──────────────────────────────┐
│ Browser Receives Response    │
│ response.json() parses JSON  │
└──────┬──────────────────────┘
       │
       ▼
┌──────────────────────────────┐
│ setProducts(data) Updates    │
│ Component State              │
└──────┬──────────────────────┘
       │
       ▼
┌──────────────────────────────┐
│ Component Re-renders with    │
│ 25 Product Cards             │
└──────────────────────────────┘
```

---

## Component Data Dependency Map

```
App Layout
│
├── Header
│   └── Needs: companies.logo, companies.name
│       API: /api/cms/companies
│
├── Hero Component
│   └── Needs: hero_slides with images and CTAs
│       API: /api/cms/slides?published=true
│
├── Products Section
│   ├── Carousel Component
│   │   └── Needs: all products with summary
│   │       API: /api/cms/products
│   │
│   └── Product Card Component
│       └── Needs: individual product details
│           API: /api/cms/products/{slug}
│
├── Why Choose Us Section
│   ├── Reviews Carousel
│   │   └── Needs: customer reviews with ratings
│   │       API: /api/cms/reviews?featured=true
│   │
│   ├── Reasons Grid
│   │   └── Needs: why choose reasons
│   │       API: /api/cms/reasons
│   │
│   └── Stats Animation
│       └── Needs: company statistics
│           API: /api/cms/config?category=stats
│
├── Team Page
│   ├── Team Grid
│   │   └── Needs: all team members
│   │       API: /api/cms/team?status=active
│   │
│   └── Member Detail
│       └── Needs: individual member info
│           API: /api/cms/team/{id}
│
├── Branches Map
│   ├── Map Component
│   │   └── Needs: all branches with coordinates
│   │       API: /api/cms/branches
│   │
│   └── Branch Card
│       └── Needs: individual branch details
│           API: /api/cms/branches/{id}
│
├── Quote Forms (per product)
│   ├── Form Renderer
│   │   └── Needs: form field configuration
│   │       API: /api/cms/forms?product={slug}
│   │
│   └── Form Submission
│       └── Posts to: /api/forms/submit
│
└── Footer
    └── Needs: company contact info, links
        API: /api/cms/config?category=contact
```

---

## Data Model Relationships

```
┌─────────────┐
│  Company    │◄─────────┐
└─────────────┘          │ belongs_to
      │                  │
      │ has_many         │
      ▼                  │
┌─────────────┐     ┌────────────┐
│  Products   │────►│  Benefits  │
└─────────────┘     └────────────┘
      │
      ├─► Coverage
      ├─► Exclusions
      ├─► FAQs
      ├─► Eligibility
      └─► HowToApply
      
    
┌─────────────┐
│  Reviews    │
└─────────────┘
      │ status (pending/approved)
      ▼


┌─────────────┐
│   Reasons   │
└─────────────┘


┌──────────────┐
│ TeamMembers  │
└──────────────┘
      │ reports_to
      ├─► Department
      └─► Branch


┌─────────────┐
│  Branches   │
└─────────────┘
      │ has_many
      ├─► Hours
      ├─► Manager (TeamMember)
      └─► Staff (TeamMembers)


┌───────────────┐
│  FormConfigs  │
└───────────────┘
      │ has_many
      └─► FormFields


┌─────────────────┐
│ Configuration   │
│ (Key-Value)     │
└─────────────────┘
      │ categories:
      ├─► colors
      ├─► email
      ├─► departments
      └─► settings
```

---

## API Response Structure Template

```javascript
// Success Response
{
  "success": true,
  "data": [
    {
      "id": "uuid-string",
      "name": "string",
      // ... entity-specific fields
      "createdAt": "ISO8601",
      "updatedAt": "ISO8601"
    },
    // ... more items
  ],
  "meta": {
    "total": 25,
    "page": 1,
    "limit": 20,
    "hasMore": true
  }
}

// Error Response
{
  "success": false,
  "error": {
    "code": "PRODUCT_NOT_FOUND",
    "message": "The requested product could not be found",
    "statusCode": 404
  }
}

// Paginated Response
{
  "success": true,
  "data": [...],
  "pagination": {
    "page": 1,
    "limit": 20,
    "total": 150,
    "pages": 8,
    "hasNext": true,
    "hasPrev": false
  }
}
```

---

## Caching Strategy

```
┌─────────────────────────────────────┐
│  Client Makes API Request           │
└──────────────┬──────────────────────┘
               │
               ▼
        ┌──────────────┐
        │ Check Local  │
        │ Cache        │
        │ (1-hour TTL) │
        └──┬───────┬───┘
         Yes│       │No
           ▼       ▼
        ┌────┐  ┌──────────────┐
        │Use │  │ Fetch from   │
        │Cache   │ API Server   │
        └────┘  └──────┬───────┘
           │            │
           │     ┌──────▼───────┐
           │     │ Cache Result │
           │     │ (localStorage)
           │     └──────┬───────┘
           │            │
           └────┬───────┘
                │
                ▼
        ┌────────────────┐
        │ Return Data    │
        │ to Component   │
        └────────────────┘

TTL (Time To Live):
- Products: 1 hour
- Reviews: 30 minutes
- Team: 2 hours
- Config: 4 hours
- Slides: 1 hour
```

---

## Error Handling Flow

```
API Request
    │
    ├─► Network Error
    │   └─► Show "Connection Failed"
    │
    ├─► HTTP Error (4xx/5xx)
    │   ├─► 400: Bad Request
    │   ├─► 401: Unauthorized (refresh auth)
    │   ├─► 403: Forbidden
    │   ├─► 404: Not Found
    │   └─► 500: Server Error (retry)
    │
    ├─► Timeout
    │   └─► Retry with exponential backoff
    │
    ├─► Invalid JSON
    │   └─► Show "Data Format Error"
    │
    └─► Success
        └─► Parse & Cache Data
```

---

## Migration Timeline

```
Week 1: Planning & Setup
  ├─ API framework selection
  ├─ Database setup
  └─ Development environment

Week 2-3: API Development
  ├─ Endpoints for Products
  ├─ Endpoints for Reviews
  ├─ Endpoints for Team
  └─ Endpoints for Other entities

Week 4: Data Migration
  ├─ Export existing data
  ├─ Create migration scripts
  └─ Validate integrity

Week 5: Frontend Integration
  ├─ Create service layer
  ├─ Build React hooks
  ├─ Update components
  └─ Test all flows

Week 6: Deployment & Monitoring
  ├─ Feature flags
  ├─ Gradual rollout
  ├─ Performance monitoring
  └─ Bug fixes
```

---

## File Structure After Migration

```
project/
├── app/
│   ├── api/
│   │   └── cms/
│   │       ├── products/
│   │       │   └── route.js
│   │       ├── reviews/
│   │       │   └── route.js
│   │       ├── team/
│   │       │   └── route.js
│   │       ├── branches/
│   │       │   └── route.js
│   │       ├── config/
│   │       │   └── route.js
│   │       └── health/
│   │           └── route.js
│   │
│   └── pages/
│       ├── products/
│       │   └── [slug]/
│       │       └── page.js (now fetches via API)
│       ├── team/
│       │   └── page.js
│       └── branches/
│           └── page.js
│
├── components/
│   ├── Products.js (uses API)
│   ├── Hero.js (uses API)
│   ├── WhyChooseUs.js (uses API)
│   ├── TeamSection.js (uses API)
│   ├── BranchMap.js (uses API)
│   └── ProductsData.js (DEPRECATED - remove after migration)
│
├── lib/
│   ├── cms-api.js (new - API service layer)
│   ├── db.js (new - database connection)
│   └── hooks/
│       └── useCMS.js (new - custom hooks)
│
├── public/
│   └── api/
│       ├── products/
│       ├── images/
│       └── assets/
│
├── STATIC_DATA_AUDIT.md (Documentation)
├── CMS_IMPLEMENTATION_GUIDE.md (Practical guide)
└── CMS_AUDIT_SUMMARY.md (This summary)
```

---

## Performance Optimization Points

```
┌─────────────────────────────────────┐
│ 1. Database Level                   │
│    - Indexes on frequently queried   │
│    - Query optimization              │
│    - Connection pooling              │
│    - Read replicas for scaling       │
└─────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────┐
│ 2. API Level                        │
│    - Pagination (limit results)     │
│    - Field selection (only needed)  │
│    - Response caching (ETag)        │
│    - Compression (gzip)             │
│    - Rate limiting                  │
└─────────────────────────────────────┘
         │
         ▼
┌─────────────────────────────────────┐
│ 3. Browser Level                    │
│    - LocalStorage caching           │
│    - Service Workers                │
│    - Code splitting                 │
│    - Image optimization             │
│    - Lazy loading                   │
└─────────────────────────────────────┘
```

---

## Monitoring & Analytics

```
Track Metrics:
├─ API Response Time (target: <200ms)
├─ Database Query Time (target: <100ms)
├─ Cache Hit Rate (target: >70%)
├─ Error Rate (target: <0.5%)
├─ Component Load Time (target: <1s)
├─ User Interaction Time (target: <500ms)
└─ Data Freshness (last updated)

Alerts:
├─ API down
├─ Response time > 1s
├─ Error rate > 2%
├─ Database connection failure
└─ Cache corruption
```

---

**Visual Reference Created**: November 11, 2025  
**Format**: ASCII Diagrams + Reference Guides  
**Use Case**: Quick understanding of architecture and data flow
