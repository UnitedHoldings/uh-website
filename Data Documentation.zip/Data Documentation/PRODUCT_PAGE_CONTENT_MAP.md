# Product Page - Content & Data Map

**Purpose**: Visual reference for data flow, component structure, and content relationships  
**Scope**: `app/products/[slug]/page.js` + `components/RenderForm.js`  
**Audience**: Developers, architects, content team

---

## 🔄 Data Flow Architecture

### Before Migration: Current Hardcoded Flow

```
┌─────────────────────────────────────────────────────────────┐
│                    User Visits Product Page                  │
│                  products/[slug]/page.js                     │
└────────────────────┬────────────────────────────────────────┘
                     │
        ┌────────────┴────────────┐
        ▼                         ▼
   ┌──────────┐           ┌──────────────────┐
   │ Product  │           │ Hardcoded Data   │
   │ API Call │           │ Objects          │
   │ (Works)  │           │ (Static)         │
   └────┬─────┘           └──────────┬───────┘
        │                           │
        ├─ productName ────────────┐│
        │                          ││
        │                  ┌───────┴┴──────────────┐
        │                  ▼                       ▼
        │          ┌─────────────────────┬──────────────────┐
        │          │ getProductCompany() │ getCompanyText() │
        │          │ Returns company obj │ Returns text obj │
        │          │ (hardcoded logic)   │ (hardcoded logic)│
        │          └────────┬────────────┴────────┬─────────┘
        │                   │                     │
        ├─ company ────┬────┘             ┌───────┘
        │              │                  │
        │              ▼                  ▼
        │       ┌─────────────────────────────────────┐
        │       │     Render Product Page             │
        │       │ - Company Name & Color (hardcoded)  │
        │       │ - Heading Text (hardcoded)          │
        │       │ - Submit Button Text (hardcoded)    │
        │       │ - Disclaimer (hardcoded)            │
        │       └──────────┬──────────────────────────┘
        │                  │
        └──────────┬───────┘
                   │
                   ▼
        ┌─────────────────────────────────┐
        │     Pass to RenderForm           │
        │  products/[slug]/page.js → line  │
        │           RenderForm            │
        └────────────┬────────────────────┘
                     │
                     ▼
        ┌──────────────────────────────────┐
        │  RenderForm Component            │
        │  - getProductCategory()          │
        │  - 7 hardcoded switch cases      │
        │  - 42+ hardcoded form fields     │
        │  - 43+ hardcoded options         │
        └────────────┬─────────────────────┘
                     │
                     ▼
        ┌──────────────────────────────────┐
        │  Render Quote Form               │
        │  - Category-specific fields      │
        │  - All hardcoded labels/options  │
        │  - Client-side validation       │
        └──────────────────────────────────┘
```

**Problem**: 120+ hardcoded data points scattered across:
- COMPANY_COLORS object
- COMPANY_NAMES object
- getCompanySpecificText() function
- RenderForm switch statement
- Select option arrays

---

### After Migration: Dynamic API Flow

```
┌─────────────────────────────────────────────────────────────┐
│                    User Visits Product Page                  │
│                  products/[slug]/page.js                     │
└────────────────────┬────────────────────────────────────────┘
                     │
        ┌────────────┼────────────┬────────────────┐
        ▼            ▼            ▼                ▼
   ┌─────────┐  ┌──────────┐  ┌──────────┐  ┌────────────┐
   │ Product │  │useProduct│  │  Auto    │  │  Zero Code │
   │ API     │  │PageData()│  │ Company  │  │   Update   │
   │ (Works) │  │  Hook    │  │Detection │  │(UI Change) │
   └────┬────┘  └────┬─────┘  └────┬─────┘  └────────────┘
        │             │             │
        │             └─────┬───────┘
        │                   │
        │        ┌──────────▼──────────┐
        │        │  API Calls (4 total) │
        │        └──────────┬───────────┘
        │                   │
        │      ┌────────────┼────────────┐
        │      ▼            ▼            ▼
        │  GET /api/    GET /api/  GET /api/
        │  cms/         cms/       cms/
        │  companies    companies/ product-
        │              :code      categories
        │      │            │            │
        │      └────────┬───┴───┬────────┘
        │              ▼       ▼
        │     ┌───────────────────────────┐
        │     │ PostgreSQL Database       │
        │     │ 4 Tables                  │
        │     │ - cms_companies           │
        │     │ - cms_product_categories  │
        │     │ - cms_form_fields         │
        │     │ - cms_select_options      │
        │     └────────┬──────────────────┘
        │              │
        │    ┌─────────┴─────────┬────────────┐
        │    ▼                   ▼            ▼
        │ Company             Category      Form Fields
        │ Data                Data          + Options
        │ {                   {             [
        │  id: '...',        categoryKey:    {
        │  code: 'UGI',      'life',         fieldKey: 'dob',
        │  name: 'United     name: 'Life     label: 'Date of',
        │  General...',      Insurance',    type: 'date',
        │  brandColor:       keywords: [...] required: true
        │  '#286278',        formFields: [...]
        │  mainHeading:      }
        │  'Hassle-free',
        │  ...
        │ }
        │
        └──────────┬──────────────────────────────────┐
                   │                                  │
                   ▼                                  ▼
        ┌──────────────────────────┐      ┌────────────────────────┐
        │ useProductPageData Hook  │      │ Automatic Detection    │
        │ - Handles API calls      │      │ - Keywords match       │
        │ - Manages loading state  │      │ - Category inference   │
        │ - Returns typed data     │      │ - Fallback logic       │
        └──────────┬───────────────┘      └────────────────────────┘
                   │
                   ▼
        ┌──────────────────────────┐
        │ product.jsx              │
        │ - Dynamic company color  │
        │ - Dynamic heading text   │
        │ - Dynamic button text    │
        │ - API disclaimer         │
        └──────────┬───────────────┘
                   │
                   ▼
        ┌──────────────────────────┐
        │ RenderForm Component     │
        │ - Map over form fields   │
        │ - Render input per type  │
        │ - Populate options       │
        │ - Apply validation       │
        └──────────┬───────────────┘
                   │
                   ▼
        ┌──────────────────────────┐
        │ Dynamic Quote Form       │
        │ (Zero hardcoded data)    │
        │ Full CMS control         │
        └──────────────────────────┘
```

**Benefit**: 120+ hardcoded points → 4 database tables → Zero code changes for updates

---

## 📦 Component Structure Diagram

### Hierarchy Tree

```
app/products/[slug]/page.js (600+ lines)
├── Metadata Export (SEO)
├── Imports & Constants
│   ├── COMPANY_COLORS (3 colors) ❌ → Move to DB
│   ├── COMPANY_NAMES (3 names) ❌ → Move to DB
│   └── Utility Functions
├── Main Component: ProductDetailPage
│   ├── useEffect → Fetch product data (API) ✓
│   ├── useState → Form state
│   ├── Render Top Section
│   │   ├── Company Brand Bar
│   │   │   ├── Company Logo/Name (hardcoded) ❌
│   │   │   └── Brand Color (hardcoded) ❌
│   │   └── Product Heading
│   ├── Render Details Grid
│   │   ├── Product Benefits Component
│   │   │   └── Hardcoded content ❌
│   │   ├── Product Coverage Component
│   │   │   └── Hardcoded content ❌
│   │   └── Product Eligibility Component
│   │       └── Hardcoded content ❌
│   ├── Render Quote Form Container
│   │   ├── Heading (hardcoded) ❌
│   │   ├── RenderForm Component
│   │   │   ├── getProductCategory() (hardcoded) ❌
│   │   │   ├── 7 switch cases (hardcoded) ❌
│   │   │   └── Form submission handler
│   │   └── Disclaimer (hardcoded) ❌
│   └── Toast Notifications
│
components/RenderForm.js (350+ lines)
├── Helper Functions
│   └── getProductCategory() (hardcoded logic) ❌
├── Main Component: RenderForm
│   ├── Props: { product, onFormSubmit, companyCode }
│   ├── State: formData, touched, errors
│   ├── Effects: Validation
│   ├── Form Render
│   │   ├── Form wrapper
│   │   ├── Map formFields (from hardcoded) ❌
│   │   │   ├── InputField (hardcoded) ❌
│   │   │   └── SelectField (hardcoded) ❌
│   │   ├── Submit Button (hardcoded text) ❌
│   │   └── Error messages
│   └── Handlers: onChange, onBlur, onSubmit
│
Database Layer (Proposed)
├── cms_companies
├── cms_product_categories
├── cms_form_fields
└── cms_select_options
```

**Legend**:
- ✓ = Works well, keep as-is
- ❌ = Hardcoded, migrate to DB

---

## 🎨 Color & Branding Map

### Current Hardcoded Colors

```
┌─────────────────────────────────────────────────────────────┐
│              COMPANY COLOR SCHEME (Hardcoded)                │
├─────────────────────────────────────────────────────────────┤
│                                                               │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ United General Insurance (UGI)                       │   │
│  │ ├─ Primary Color: #286278 (Dark Blue)               │   │
│  │ ├─ Usage: Header, buttons, accents                  │   │
│  │ ├─ Contrast: ✓ WCAG AA (blue on white)            │   │
│  │ └─ Location: app/products/[slug]/page.js line 2    │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                               │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ United Life Assurance (ULA)                          │   │
│  │ ├─ Primary Color: #3d834d (Dark Green)              │   │
│  │ ├─ Usage: Header, buttons, accents                  │   │
│  │ ├─ Contrast: ✓ WCAG AA (green on white)            │   │
│  │ └─ Location: app/products/[slug]/page.js line 3    │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                               │
│  ┌──────────────────────────────────────────────────────┐   │
│  │ United Pay (UP)                                      │   │
│  │ ├─ Primary Color: #f79620 (Orange)                  │   │
│  │ ├─ Usage: Header, buttons, accents                  │   │
│  │ ├─ Contrast: ✗ WCAG AA FAILS (orange on white)    │   │
│  │ ├─ Issue: 3.65:1 ratio (need 4.5:1)                │   │
│  │ ├─ Solution: Use darker shade #d67910              │   │
│  │ └─ Location: app/products/[slug]/page.js line 4    │   │
│  └──────────────────────────────────────────────────────┘   │
│                                                               │
└─────────────────────────────────────────────────────────────┘
```

### Proposed Database Storage

```
cms_companies Table
┌────────────────────────────────────────────┐
│ id  │ code│ brand_color │ ...              │
├─────┼─────┼─────────────┼──────────────────┤
│ 1   │ UGI │ #286278     │ ...              │
│ 2   │ ULA │ #3d834d     │ ...              │
│ 3   │ UP  │ #d67910     │ ... (updated!)   │
└────────────────────────────────────────────┘
```

---

## 📄 Company-Specific Text Map

### Content Structure

```
┌────────────────────────────────────────────────────────────────┐
│           Company-Specific Text Fields (5 per company)          │
├────────────────────────────────────────────────────────────────┤
│                                                                  │
│  Field 1: Main Heading                                         │
│  ├─ UGI: "Hassle-free cover for your insurance needs"        │
│  ├─ ULA: "Peace of mind with life assurance coverage"        │
│  └─ UP:  "Get hassle-free financing for all your needs"     │
│  Location: app/products/[slug]/page.js line 55               │
│                                                                  │
│  Field 2: Action Text                                          │
│  ├─ UGI: "Get Quote"                                          │
│  ├─ ULA: "Calculate Premium"                                 │
│  └─ UP:  "Apply Now"                                         │
│  Location: app/products/[slug]/page.js line 56               │
│                                                                  │
│  Field 3: Success Message                                      │
│  ├─ UGI: "Your insurance quote has been generated"           │
│  ├─ ULA: "Your life assurance quote is ready"               │
│  └─ UP:  "Your application has been submitted"              │
│  Location: app/products/[slug]/page.js line 57               │
│                                                                  │
│  Field 4: Form Title                                           │
│  ├─ UGI: "Get Your Insurance Quote"                          │
│  ├─ ULA: "Life Assurance Calculator"                         │
│  └─ UP:  "Quick Loan Application"                            │
│  Location: app/products/[slug]/page.js line 58               │
│                                                                  │
│  Field 5: Submit Button Text                                   │
│  ├─ UGI: "Request Quote"                                     │
│  ├─ ULA: "Calculate Premium"                                 │
│  └─ UP:  "Submit Application"                                │
│  Location: app/products/[slug]/page.js line 59               │
│                                                                  │
└────────────────────────────────────────────────────────────────┘
```

### Database Mapping

```
cms_companies Table
┌──────────┬──────────────────────┬───────────┬─────────┬──────────┐
│ company_ │ main_heading         │ action_   │ form_   │ submit_  │
│ id       │                      │ text      │ title   │ button   │
├──────────┼──────────────────────┼───────────┼─────────┼──────────┤
│ UGI      │ Hassle-free cover... │ Get Quote │ Get Your│ Request  │
│          │                      │           │ Insurance│ Quote   │
├──────────┼──────────────────────┼───────────┼─────────┼──────────┤
│ ULA      │ Peace of mind...     │ Calculate │ Life    │ Calculate│
│          │                      │ Premium   │ Assurance│ Premium  │
├──────────┼──────────────────────┼───────────┼─────────┼──────────┤
│ UP       │ Get hassle-free...   │ Apply Now │ Quick   │ Submit   │
│          │                      │           │ Loan App│Application
└──────────┴──────────────────────┴───────────┴─────────┴──────────┘
```

---

## 📋 Form Field Matrix

### Category-to-Fields Mapping

```
┌────────────────────────────────────────────────────────────────┐
│         Product Category → Form Fields (Current)                │
├────────────────────────────────────────────────────────────────┤
│                                                                  │
│ LIFE INSURANCE (5 fields)                                      │
│ ├─ Date of Birth (date input)                                 │
│ ├─ Gender (select: Male/Female)                               │
│ ├─ Coverage Amount (number input)                             │
│ ├─ Coverage Type (select: Individual/Family)                  │
│ └─ Number of Dependents (number input)                        │
│ Location: RenderForm.js lines 46-75                           │
│                                                                  │
│ MOTOR INSURANCE (6 fields)                                     │
│ ├─ Vehicle Type (select: Car/Motorcycle/Truck)               │
│ ├─ Vehicle Make (text input)                                  │
│ ├─ Vehicle Model (text input)                                 │
│ ├─ Year of Manufacture (number input)                         │
│ ├─ Registration Number (text input)                           │
│ └─ Vehicle Value (currency input)                             │
│ Location: RenderForm.js lines 76-110                          │
│                                                                  │
│ HOME INSURANCE (6 fields)                                      │
│ ├─ Property Address (text input)                              │
│ ├─ Property Status (select: Owned/Rented)                     │
│ ├─ Property Type (select: House/Flat/Other)                  │
│ ├─ Property Value (currency input)                            │
│ ├─ Coverage Type (select: Building/Contents/Both)             │
│ └─ Years Insured (number input)                               │
│ Location: RenderForm.js lines 111-145                         │
│                                                                  │
│ LEGAL INSURANCE (4 fields)                                     │
│ ├─ Legal Matter (select: Employment/Contract/Other)           │
│ ├─ Estimated Costs (currency input)                           │
│ ├─ Urgency (select: Low/Medium/High)                          │
│ └─ Description (textarea)                                     │
│ Location: RenderForm.js lines 146-170                         │
│                                                                  │
│ PERSONAL ACCIDENT (4 fields)                                   │
│ ├─ Date of Birth (date input)                                 │
│ ├─ Occupation (text input)                                    │
│ ├─ Coverage Amount (currency input)                           │
│ └─ Activity Coverage (select: Standard/High-Risk)             │
│ Location: RenderForm.js lines 171-195                         │
│                                                                  │
│ BUSINESS INSURANCE (7 fields)                                  │
│ ├─ Business Name (text input)                                 │
│ ├─ Registration Number (text input)                           │
│ ├─ Business Type (select: Retail/Service/Other)               │
│ ├─ Number of Employees (number input)                         │
│ ├─ Annual Revenue (currency input)                            │
│ ├─ Coverage Type (select: Liability/Property/Both)            │
│ └─ Business Address (text input)                              │
│ Location: RenderForm.js lines 196-235                         │
│                                                                  │
│ LOANS (6 fields)                                               │
│ ├─ Loan Amount (currency input)                               │
│ ├─ Loan Purpose (select: Car/Home/Personal/Other)             │
│ ├─ Employment Status (select: Employed/Self-Employed)        │
│ ├─ Monthly Income (currency input)                            │
│ ├─ Loan Tenure (number input - years)                         │
│ └─ Existing Loans (select: Yes/No)                            │
│ Location: RenderForm.js lines 236-270                         │
│                                                                  │
└────────────────────────────────────────────────────────────────┘
```

### Database Schema

```
cms_product_categories
┌──────────┬──────────────┬──────────┐
│ id       │ category_key │ name     │
├──────────┼──────────────┼──────────┤
│ 1        │ life         │ Life     │
│ 2        │ motor        │ Motor    │
│ 3        │ home         │ Home     │
│ 4        │ legal        │ Legal    │
│ 5        │ personal-acc │ Personal │
│ 6        │ business     │ Business │
│ 7        │ loan         │ Loan     │
└──────────┴──────────────┴──────────┘

cms_form_fields
┌──────────┬────────────────┬────────┬──────────────┐
│ id       │ category_id    │ label  │ type         │
├──────────┼────────────────┼────────┼──────────────┤
│ 1        │ 1 (Life)       │ DOB    │ date         │
│ 2        │ 1 (Life)       │ Gender │ select       │
│ 3        │ 1 (Life)       │ Amount │ number       │
│ ...      │ ...            │ ...    │ ...          │
│ 43       │ 7 (Loan)       │ Tenure │ number       │
└──────────┴────────────────┴────────┴──────────────┘

cms_select_options
┌────┬──────────┬──────────┬────────┐
│ id │ field_id │ value    │ label  │
├────┼──────────┼──────────┼────────┤
│ 1  │ 2        │ M        │ Male   │
│ 2  │ 2        │ F        │ Female │
│ 3  │ 5        │ car      │ Car    │
│ 4  │ 5        │ moto     │ Moto   │
│ .. │ ..       │ ..       │ ..     │
│ 43 │ 37       │ yes      │ Yes    │
└────┴──────────┴──────────┴────────┘
```

---

## 🔍 Product Detection Logic Map

### Current Keyword Matching (Hardcoded)

```
User visits: /products/life-insurance

┌─────────────────────────────┐
│ Product Slug: "life-..."   │
└────────┬────────────────────┘
         │
         ▼
┌─────────────────────────────┐
│ Keyword.includes('life')    │
│ Case-insensitive match      │
└────────┬────────────────────┘
         │
         ▼
┌─────────────────────────────┐
│ Return category = "life"    │
│ Hardcoded logic ❌          │
└────────┬────────────────────┘
         │
         ▼
┌─────────────────────────────┐
│ Switch(category) {          │
│   case 'life': {...fields}  │
│   ...                       │
│ }                           │
└─────────────────────────────┘
```

### Proposed API-Driven Matching

```
User visits: /products/life-insurance

┌─────────────────────────────────┐
│ Product Slug: "life-..."       │
└────────┬────────────────────────┘
         │
         ▼
┌──────────────────────────────────┐
│ GET /api/cms/product-categories  │
│ Fetch all categories with keywords
└────────┬───────────────────────────┘
         │
         ▼
┌──────────────────────────────────┐
│ Filter categories by keywords    │
│ Find best match using fuzzy match│
│ Example: 'life-insurance' →     │
│   'life' category               │
└────────┬───────────────────────────┘
         │
         ▼
┌──────────────────────────────────┐
│ Return matched category object   │
│ With all form fields from API    │
│ Zero hardcoded data ✓            │
└──────────────────────────────────┘
```

---

## 📱 Responsive Layout Map

### Desktop Layout (1024px+)

```
┌─────────────────────────────────────────────────────────┐
│ Header (Navigation)                                     │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  ┌────────────────┐                                    │
│  │ Company Logo   │ Main Product Heading               │
│  │ [Color]        │ "Get hassle-free cover..."        │
│  └────────────────┘                                    │
│                                                          │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐   │
│  │ Benefits    │  │ Coverage    │  │ Eligibility │   │
│  ├─────────────┤  ├─────────────┤  ├─────────────┤   │
│  │ • Benefit 1 │  │ • Coverage  │  │ • Criteria  │   │
│  │ • Benefit 2 │  │ • Coverage  │  │ • Criteria  │   │
│  │ • Benefit 3 │  │ • Coverage  │  │ • Criteria  │   │
│  └─────────────┘  └─────────────┘  └─────────────┘   │
│                                                          │
├─────────────────────────────────────────────────────────┤
│                                                          │
│  ┌──────────────────────────────────────────────────┐  │
│  │ Get Your Quote                                   │  │
│  ├──────────────────────────────────────────────────┤  │
│  │ [Form Fields - Category Specific]                │  │
│  │ • Field 1: __________ [Dropdown/Input]          │  │
│  │ • Field 2: __________ [Dropdown/Input]          │  │
│  │ • Field 3: __________ [Dropdown/Input]          │  │
│  │ • Field 4: __________ [Dropdown/Input]          │  │
│  │ • Field 5: __________ [Dropdown/Input]          │  │
│  │                                                   │  │
│  │              [Submit Application]                │  │
│  │                                                   │  │
│  │ Disclaimer: "By submitting... UP..."             │  │
│  └──────────────────────────────────────────────────┘  │
│                                                          │
├─────────────────────────────────────────────────────────┤
│ Footer                                                  │
└─────────────────────────────────────────────────────────┘
```

### Mobile Layout (< 640px)

```
┌──────────────────┐
│ Header           │
├──────────────────┤
│                  │
│  [Logo]          │
│  Heading         │
│  "Get hassle-"   │
│  "free cover"    │
│                  │
├──────────────────┤
│                  │
│ Benefits         │
│ ├─ Benefit 1    │
│ ├─ Benefit 2    │
│ └─ Benefit 3    │
│                  │
│ Coverage         │
│ ├─ Coverage 1   │
│ ├─ Coverage 2   │
│ └─ Coverage 3   │
│                  │
│ Eligibility      │
│ ├─ Criteria 1   │
│ ├─ Criteria 2   │
│ └─ Criteria 3   │
│                  │
├──────────────────┤
│                  │
│ Get Your Quote   │
│ ├─ [Field 1]   │
│ ├─ [Field 2]   │
│ ├─ [Field 3]   │
│ ├─ [Field 4]   │
│ ├─ [Field 5]   │
│ └─ [Submit]    │
│                  │
│ Disclaimer       │
│                  │
├──────────────────┤
│ Footer           │
└──────────────────┘
```

---

## 🗂️ File Organization After Migration

### Before (Hardcoded)

```
app/
├── products/
│   └── [slug]/
│       └── page.js (600+ lines, hardcoded data)
│
components/
├── RenderForm.js (350+ lines, hardcoded fields)
├── ProductBenefits.js (hardcoded content)
├── ProductCoverage.js (hardcoded content)
└── ProductEligibility.js (hardcoded content)
```

### After (CMS-Driven)

```
app/
├── api/
│   └── cms/
│       ├── companies/
│       │   ├── route.js (GET all companies)
│       │   └── [code]/
│       │       └── route.js (GET single company)
│       └── product-categories/
│           ├── route.js (GET all categories)
│           └── [key]/
│               └── route.js (GET single category)
│
├── products/
│   └── [slug]/
│       └── page.js (cleaner, data from API)
│
lib/
├── cms-product-api.js (service layer)
│   ├── getCompanies()
│   ├── getCompanyByCode()
│   ├── getProductCategories()
│   └── getProductCategoryByKey()
│
hooks/
├── useProductPageData.js (custom hook)
│   ├── Fetch company data
│   ├── Detect category from slug
│   ├── Return typed data
│   └── Handle loading/errors
│
components/
├── RenderForm.js (dynamic, data-driven)
├── ProductBenefits.js (cleaner)
├── ProductCoverage.js (cleaner)
└── ProductEligibility.js (cleaner)

database/
├── migrations/
│   ├── 001_create_companies.sql
│   ├── 002_create_product_categories.sql
│   ├── 003_create_form_fields.sql
│   └── 004_create_select_options.sql
│
└── seeds/
    └── seed-product-data.sql (populate from hardcoded)
```

---

## 🔗 Data Dependencies Graph

### What Depends on What

```
Product Slug
    │
    ├─────────────────────────┬──────────────────────┐
    │                         │                      │
    ▼                         ▼                      ▼
Company Detection      Category Detection      Product Details
    │                         │                      │
    ├─ Get company code   ├─ Match keywords      ├─ Product from API
    └─ Fetch company      └─ Get category       └─ Company-specific text
        from API             from API
    │                         │                      │
    └─────────────────┬───────┴──────────────┬──────┘
                      │                      │
                      ▼                      ▼
              Render Company Info    Render Form Fields
                      │                      │
                      ├─ Brand Color        ├─ Category fields
                      ├─ Company Name       ├─ Form labels
                      ├─ Heading Text       ├─ Select options
                      └─ Submit Button      └─ Validation rules
                           Text
                      │                      │
                      └─────────────┬────────┘
                                   │
                                   ▼
                          Complete Product Page
```

---

## 🎓 Migration Checklist by Component

### Company Branding

```
Current Location: app/products/[slug]/page.js (lines 1-30)

☐ ANALYZE
  ☐ Identify all company references
  ☐ Document color usage
  ☐ List all text fields

☐ DATABASE
  ☐ Create cms_companies table
  ☐ Add 3 company records
  ☐ Verify constraints

☐ API
  ☐ Create GET /api/cms/companies
  ☐ Create GET /api/cms/companies/:code
  ☐ Test with cURL/Postman

☐ CODE
  ☐ Create service layer function
  ☐ Create useCompanyData hook
  ☐ Update product page component
  ☐ Remove COMPANY_COLORS constant
  ☐ Remove COMPANY_NAMES constant
  ☐ Remove company-specific text logic

☐ TEST
  ☐ Colors load correctly
  ☐ Text displays from API
  ☐ Responsive design preserved
  ☐ No console errors
```

### Form Fields

```
Current Location: components/RenderForm.js (lines 46-270)

☐ ANALYZE
  ☐ Identify all 7 categories
  ☐ Count fields per category
  ☐ List all select options
  ☐ Document validation rules

☐ DATABASE
  ☐ Create cms_product_categories
  ☐ Create cms_form_fields
  ☐ Create cms_select_options
  ☐ Add 7 category records
  ☐ Add 42+ field records
  ☐ Add 43+ option records
  ☐ Verify relationships

☐ API
  ☐ Create GET /api/cms/product-categories
  ☐ Create GET /api/cms/product-categories/:key
  ☐ Test with cURL/Postman

☐ CODE
  ☐ Create service layer functions
  ☐ Create useProductCategoryData hook
  ☐ Update RenderForm component
  ☐ Remove switch statements
  ☐ Dynamic field rendering
  ☐ Dynamic option population

☐ TEST
  ☐ All 7 categories render
  ☐ Correct fields per category
  ☐ Correct options per field
  ☐ Validation works
  ☐ Form submission works
  ☐ No console errors
```

---

## 📊 Content Summary Table

### All Hardcoded Items Inventory

| Category | Item | Current Location | Type | Count |
|----------|------|------------------|------|-------|
| Colors | Brand colors | page.js:1-5 | Constants | 3 |
| Names | Company names | page.js:6-10 | Constants | 3 |
| Text | Headings | page.js:256-291 | Switch stmt | 5 |
| Text | Button text | page.js:256-291 | Switch stmt | 5 |
| Text | Messages | page.js:256-291 | Switch stmt | 5 |
| Form | Life fields | RenderForm:46-75 | Switch case | 5 |
| Form | Motor fields | RenderForm:76-110 | Switch case | 6 |
| Form | Home fields | RenderForm:111-145 | Switch case | 6 |
| Form | Legal fields | RenderForm:146-170 | Switch case | 4 |
| Form | Personal fields | RenderForm:171-195 | Switch case | 4 |
| Form | Business fields | RenderForm:196-235 | Switch case | 7 |
| Form | Loan fields | RenderForm:236-270 | Switch case | 6 |
| Options | Select values | RenderForm:80-200 | Arrays | 43+ |
| Text | Disclaimers | page.js:290-310 | Conditional | 2 |
| **TOTAL** | | | | **120+** |

---

## ✅ Success Criteria Checklist

- [ ] All 3 colors from database
- [ ] All text strings from database
- [ ] All 7 form categories dynamic
- [ ] All 42+ fields from database
- [ ] All 43+ options from database
- [ ] Category detection automatic
- [ ] Form submission working
- [ ] Responsive design maintained
- [ ] Zero hardcoded data in components
- [ ] All API endpoints tested
- [ ] TypeScript types correct
- [ ] Error handling complete
- [ ] Loading states working
- [ ] No console errors
- [ ] WCAG accessibility met

---

**Content Status**: ✅ Complete  
**Ready for**: Design Review, Implementation Planning  
**Next Phase**: Database Setup & API Development
